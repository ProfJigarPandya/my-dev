if test "$0" == "date.sh"
then

date

elif test "$0" == "cal.sh"

then

cal

elif test "$0" == "ls.sh"

then

ls

else

echo "sorry"

fi
