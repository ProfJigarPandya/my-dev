date
echo  "Who are you?"
read name
echo "Hello",$name 
