echo "enter the no from 1 to 10"
read number
if test $number -lt 5
then 
echo "no is less then 5"
fi 
