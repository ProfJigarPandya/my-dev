for  var in "for.sh"
 do
    echo “ value for var is : $var”
cat $var
done
