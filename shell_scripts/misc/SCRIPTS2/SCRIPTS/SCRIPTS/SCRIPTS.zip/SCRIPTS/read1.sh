#
#read data
#

echo -e " Enter your first name : \n"
read fname
echo " my name is : $fname"

