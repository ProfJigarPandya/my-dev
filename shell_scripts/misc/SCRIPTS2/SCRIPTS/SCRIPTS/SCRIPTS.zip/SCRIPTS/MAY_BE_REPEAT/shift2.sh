#
# read arguments from command line
#

echo -e "first 9 arguments are :"
echo -e "$1 $2 $3 $4 $5 $6 $7 $8 $9 \n"
shift 9
echo -e "last nine arguments are :"
echo -e "$1 $2 $3 $4 $5 $6 $7 $8 $9 \n"
