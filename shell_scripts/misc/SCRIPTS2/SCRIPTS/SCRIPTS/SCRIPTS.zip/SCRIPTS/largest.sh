ls -ltr  | sort -n   -k24,33 | tail -n2 | head -n1
