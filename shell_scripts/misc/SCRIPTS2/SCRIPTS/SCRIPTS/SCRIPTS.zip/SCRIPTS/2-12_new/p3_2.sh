i=1
for i in `seq 1 100`
do
echo "$i"
done


