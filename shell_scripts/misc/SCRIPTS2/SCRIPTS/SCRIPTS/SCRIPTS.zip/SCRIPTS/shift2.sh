#
#pattern
#
#set a b c d
echo $*
shift 1
echo $*
shift 2
echo $*
shift 1
echo $*
