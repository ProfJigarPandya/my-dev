#
# Script to print user information who currently login , current date & time
#
echo "Hello `whoami`"
echo "Today is `date` "
echo  -e  "Number of user login :`who|wc -l`  \n  "
echo -e "Calendar \n `cal` "
