
clear
echo  -e "Hello $USER"
echo -e  "Today \c"
echo "Number of Users logged in"; who | wc -l
echo "Calendar"
cal
