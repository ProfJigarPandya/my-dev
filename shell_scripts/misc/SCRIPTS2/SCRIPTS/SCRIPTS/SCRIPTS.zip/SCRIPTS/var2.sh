fruit=apple
echo $fruit
