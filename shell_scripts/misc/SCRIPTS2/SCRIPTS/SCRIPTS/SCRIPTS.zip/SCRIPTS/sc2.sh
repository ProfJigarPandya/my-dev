#
# Script to test MY knowledge about variables!
#
myname=abc
myos = linux
#myos=linux
myno=5
branch=""
echo "My name is $myname"
echo "My os is $myos"
echo "my number is myno"
#echo "My number is $myno"
echo "my branch is $branch"
