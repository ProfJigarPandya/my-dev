#
#Arithmetic example
#
r $a + $b`
echo $c





echo "`expr $a + $b`"
