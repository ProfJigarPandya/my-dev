for (( i=1 ; i<=20 ; i++))
do 
echo  "$i"
done
