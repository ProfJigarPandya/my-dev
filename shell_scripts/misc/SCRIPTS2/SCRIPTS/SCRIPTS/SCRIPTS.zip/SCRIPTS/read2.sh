#
# read more argument from the command line
#

read a b c

echo "value of a is :$a"
echo "value of b is :$b"
echo "value of c is :$c"
