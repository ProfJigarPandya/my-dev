read x y z

a=`expr $x $y $z `
echo "$a"

