for  var in  abc def ghi xyz
 do
    echo “ value for var is : $var”
done
