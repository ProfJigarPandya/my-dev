#
#Arithmetic example
#
a=20
b=10
#c=`expr $a + $b`
echo "`expr $a + $b`"
