#
# variables
#
a=10
echo -e "Value of a is : $a"
b=
echo -e "Value of b is : $b"
c=""
echo -e "Value of c is : $c"
